// When started from bootf we get to this code with a temporary GDT,
// a temporary stack, temporary page tables, no TSS, no IDT and interrupts
// disabled.
//
// There is a fair amount of ASM work to be done before we can do much safely
// in C;  But ignoring all that we execute some C code just to prove we got
// here.

char message[] = "Executing the C code";
void test(void) {
	char *source = message;
	char *destination = (char *)0xB8000;

	while (*source) {
		*destination++ = *source++;
		*destination++ = 7; }

	for (;;) ; // Hang:  There is nowhere to return to
}

