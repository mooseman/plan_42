#ifndef __TL__SIZE_T_H
#define	__TL__SIZE_T_H

#ifdef __cplusplus
extern "C"
{
#endif

typedef unsigned size_t;

#ifdef __cplusplus
}
#endif

#endif
