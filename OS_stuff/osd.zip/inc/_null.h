#ifndef __TL__NULL_H
#define	__TL__NULL_H

#ifdef __cplusplus
extern "C"
{
#endif

#define	NULL	0

#ifdef __cplusplus
}
#endif

#endif
