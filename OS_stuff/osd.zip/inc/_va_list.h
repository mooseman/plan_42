#ifndef __TL__VA_LIST_H
#define	__TL__VA_LIST_H

#ifdef __cplusplus
extern "C"
{
#endif

typedef unsigned char *va_list;

#ifdef __cplusplus
}
#endif

#endif
