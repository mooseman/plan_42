#include "k_defines.h"

inline void outportb(unsigned int port, unsigned char value);
inline void outportw(unsigned int port, unsigned int value);
inline unsigned char inportb(unsigned short port);

void remap_pics(int pic1, int pic2);

unsigned int panic(char *message);

void k_clear_screen();
unsigned int k_printf(char *message, unsigned int line);
void update_cursor(int row, int col);

void enable_ints()
{
	asm("sti");
};
void disable_ints()
{
	asm("cli");
};

k_main() // like main
{
	k_clear_screen();

	k_printf("Welcome to Simplified OS.", 0);
	update_cursor(1, 0);
	k_printf("Right now the kernel is loaded at 1MB physical,/nbut mapped at FF800000 hex.", 3);
	update_cursor(5, 0);

	k_printf("Remapping the PIC...", 6);
	update_cursor(7,0);
	remap_pics(0x20, 0x28);	// irq 0 20h irq 8 28h
	k_printf("PIC remapped starting at 20 hex.", 7);
	update_cursor(8,0);
};

void k_clear_screen() // clear the entire text screen
{
	char *vidmem = (char *) 0xb8000;
	unsigned int i=0;
	while(i<(80*2*25))
	{
		vidmem[i]=' ';
		i++;
		vidmem[i]=WHITE_TXT;
		i++;
	};
};

unsigned int k_printf(char *message, unsigned int line)
{
	char *vidmem = (char *) 0xb8000;
	unsigned int i=0;

	i=(line*80*2);

	while(*message!=0) // 24h
	{
		if(*message==0x2F)
		{
			*message++;
			if(*message==0x6e)
			{
				line++;
				i=(line*80*2);
				*message++;
				if(*message==0)
				{
					return(1);
				};
			};
		};
		vidmem[i]=*message;
		*message++;
		i++;
		vidmem[i]=0x7;
		i++;
	};

	return(1);
};

/* ==============  */

inline void outportb(unsigned int port,unsigned char value)  // Output a byte to a port
{
    asm volatile ("outb %%al,%%dx"::"d" (port), "a" (value));
};

inline void outportw(unsigned int port,unsigned int value)  // Output a word to a port
{
    asm volatile ("outw %%ax,%%dx"::"d" (port), "a" (value));
};

inline unsigned char inportb(unsigned short port)
{
	unsigned char ret_val;

	asm volatile("inb %w1,%b0"
		: "=a"(ret_val)
		: "d"(port));
	return ret_val;
};

/* ==============  */

/* by DF */
void update_cursor(int row, int col)
{
	USHORT	position=(row*80) + col;
	// cursor LOW port to vga INDEX register
	outportb(0x3D4, 0x0F);
	outportb(0x3D5, (UCHAR)(position&0xFF));
	// cursor HIGH port to vga INDEX register
	outportb(0x3D4, 0x0E);
	outportb(0x3D5, (UCHAR)((position>>8)&0xFF));
};

void remap_pics(int pic1, int pic2)
{
	UCHAR	a1, a2;

	a1=inportb(PIC1_DATA);
	a2=inportb(PIC2_DATA);

	outportb(PIC1_COMMAND, ICW1_INIT+ICW1_ICW4);
	outportb(PIC2_COMMAND, ICW1_INIT+ICW1_ICW4);
	outportb(PIC1_DATA, pic1);
	outportb(PIC2_DATA, pic2);
	outportb(PIC1_DATA, 4);
	outportb(PIC2_DATA, 2);
	outportb(PIC1_DATA, ICW4_8086);
	outportb(PIC2_DATA, ICW4_8086);
	
	outportb(PIC1_DATA, a1);
	outportb(PIC2_DATA, a2);
};

unsigned int panic(char *message)
{
	char *vidmem = (char *) 0xb8000;
	unsigned int i=0;
	unsigned int line=0;

	i=(line*80*2);

	while(*message!=0) // 24h
	{
		if(*message==0x2F)
		{
			*message++;
			if(*message==0x6e)
			{
				line++;
				i=(line*80*2);
				*message++;
				if(*message==0)
				{
					return(1);
				};
			};
		};
		vidmem[i]=*message;
		*message++;
		i++;
		vidmem[i]=0x9; // use blue text
		i++;
	};
	return(1);
};
