/*
	text.c
	------
	Description:
	Text output for the VGA console
	by: Frank Millea, Sept. 15-17, 2002.
*/

#include "cbl.h"

void prints(char *s)
{
	while(*s)
	{
		if(*s == '\n')
		{
			putc('\r');
			putc('\n');
		}
		else
		{
			putc(*s);
		}
		*s++;
	}
}

char *ntostr(ulong n, ulong b, char *s)
{
	char temp[33], digit;
	ulong m, r;
	ushort i, j, k;

	i = 0;
	do
	{
		m = n;
		ldiv(&n, &b, &r);	/* divide n by base */
		lmul(&n, &b);	/* multiply n by b to isolate the digit */
		digit = m - n;
		/* change the numerical digit to printable ASCII value */
		if(digit <= 9)	/* decimal digit */
		{
			temp[i] = digit + '0';
		}
		else	/* hex or ? digit */
		{
			temp[i] = digit - 0x0A + 'A';
		}
		ldiv(&n, &b, &r);	/* divide n by b again to get to the next digit */
		i++;
	}
	while(n != 0);
	temp[i] = '\0';	/* add a terminator */
	k = i;	/* save i */

	/* now flip the string */
	j = k - 1;
	for(i=0; i<k; i++)
	{
		s[i] = temp[j];
		j--;	/* decrement j while incrementing i */
	}
	s[i] = '\0';	/* terminate the string */

	return s;
}
