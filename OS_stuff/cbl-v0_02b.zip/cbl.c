/*
	cbl.c
	-----
	Description:
	Cottontail Bootloader main source file
	by: Frank Millea, Sept. 15-23, 2002. (v0.01)
	updated: Sept. 28, 2002. (v0.02)
*/

#include "cbl.h"
#include "fat.h"

/******* 'old' and extended sets of disk parameters from the BIOS *******/
ushort old_cyls;
uchar old_heads, old_spt;
char use_ext = 0;
bios_ext_drive_parm_buf_t ext_parms;

/******* drive we are booting from *******/
uchar boot_drive;

/******* current data segment *******/
extern ushort data_seg;

/******* type of file system *******/
uchar fs_type;

/******* modules loaded into memory *******/
ushort num_mods = 1;
mod_t mods[MAX_MODS] = {{0x00000, 65536, "CBL 0.02"}};	/* first module is us */

void cbl_main(void *bs, uchar drive, ushort *boot_seg, ushort *boot_offs)
{
	/***************************************************************************
	Description:
	Main function of the Cottontail Bootloader. Called by the stub code once the
	environment has been set up.
	***************************************************************************/
	ulong tot_clust, den, rem, m1, m2, temp;
	uchar conf_data[4096];
	fat_short_de_t de;
	fat_file_t conf;
	size_t i;
	char str[20], b;

	/* save boot drive */
	boot_drive = drive;

	prints("\n");
	prints("������������������������������������������������������������������������������ͻ");
	prints("�                         Cottontail Bootloader v0.02                          �");
	prints("�                         ���������������������������                          �");
	prints("�                       Copyright (C) 2002, Frank Millea                       �");
	prints("�                                                                              �");
	prints("� http://www.cottontail-os.com/                                                �");
	prints("� frankm29a@aol.com                                                            �");
	prints("������������������������������������������������������������������������������ͼ");	

	/* detect filesystem type */
	fat_init(bs);

	prints("fs_type=");
	prints(ntostr(fs_type, 10, str));
	prints("\n");

	/* determine disk parameters */
	assert(!bios_get_drive_parms_old_chs(boot_drive, &old_cyls, &old_heads, \
		&old_spt), "BIOS get 'old' drive parms failed");
	old_cyls++;
	old_heads++;
	prints("* drive 'old' CHS parameters are ");
	prints(ntostr(old_cyls, 10, str));
	prints(" ");
	prints(ntostr(old_heads, 10, str));
	prints(" ");
	prints(ntostr(old_spt, 10, str));
	prints(" *\n");
	if(boot_drive >= 0x80)	/* if booting from something other than a floppy */
	{
		/* don't want the extra info, just barebones stuff */
		ext_parms.size = 0x1A;
		if(!bios_get_drive_parms_ext(boot_drive, &ext_parms))
		{
			prints("* using extended BIOS disk commands, CHS parms are ");
			prints(ntostr(ext_parms.num_cyls, 10, str));
			prints(" ");
			prints(ntostr(ext_parms.num_heads, 10, str));
			prints(" ");
			prints(ntostr(ext_parms.num_spt, 10, str));
			prints(" *\n");
			use_ext = 1;
		}
	}

	/* reset drive */
	assert(!bios_reset_disk_system(boot_drive), "drive reset failed");

	/* load cbl.conf and parse it */
	assert(find_fat_root_file("CBL_CONFTXT", &de) == 0, \
		"unable to find cbl_conf.txt");

	for(i=0; i<80; i++)
	{
		putc('@');
	}
	prints("-> Executing configuration script:\n");

	conf.bytes_left = de.size;
	conf.curr_clus = de.start_clus_lo | (de.start_clus_hi << 16);
	conf.clus_offs = 0;
	conf.sec_offs = 4096;
	conf.fat_sec = 0;

	parse(&conf);
	if(num_mods == 1)
	{
		assert(0, "no modules were loaded");
	}
	/* tell the stub to boot the first module */
	temp = mods[1].lin_addr;
	*boot_offs = temp & 0xF;
	lrsh(&temp, 4);
	*boot_seg = (ushort)temp;
}

void parse(fat_file_t *f)
{
	/***************************************************************************
	Parses and interprets the cbl_conf.txt file.
	***************************************************************************/

	ulong addr, temp;
	ushort seg, offs;
	uchar str[3][81], shortname[13], b;
	char page_align = 0;
	mod_t *mod_p;
	fat_file_t mf;
	fat_short_de_t de;

	for(;;)
	{
		parse_word(f, 0, str[0], 80);
		if(strlen(str[0]) == 0)
		{
			return;
		}
		if(!memcmp(str[0], "version", 7))
		{
			parse_word(f, 0, str[1], 80);	/* read the version number */
			if(memcmp(str[1], CBL_VER_STR, CBL_VER_LEN))	/* if versions 
				don't match */
			{
				prints(str[1]);
				prints("\ncbl_conf.txt version does not match this version.");
				prints("\nDownload the latest version from http://www.cottontail-os.com/");
				for(;;);
			}
		}
		else if(!memcmp(str[0], "load", 4))
		{
			parse_word(f, 0, str[1], 80);	/* read the filename */
			if(strlen(str[1]) > 12)
			{
				prints(str[1]);
				prints(": filename not understood.");
				for(;;);
			}
			fat_name_to_shortname(str[1], shortname);	/* convert it */
			parse_word(f, 0, str[2], 80);	/* read the address to load at */
			if(num_mods > MAX_MODS)
			{
				assert(0, "MAX_MODS exceeded");
			}
			mod_p = &mods[num_mods];
			if(!memcmp(str[2], "*", 1))	/* load right after previous module */
			{
				mod_p->lin_addr = mods[num_mods-1].lin_addr + \
					mods[num_mods-1].size;
			}
			else
			{
				mod_p->lin_addr = strton(str[2], 16);	/* convert the string
					to a number */
			}
			if(page_align)	/* align the module's load address */
			{
				if(mod_p->lin_addr & 0xFFF)
				{
					mod_p->lin_addr &= ~0xFFF;
					mod_p->lin_addr += 4096;
				}
			}
			memcpy(mod_p->name, str[1], strlen(str[1]));
			if(find_fat_root_file(shortname, &de) != 0)
			{
				prints("boot panic: couldn't locate ");
				prints(str[1]);
				prints(" in the root directory.\n");
				for(;;);
			}
			mod_p->size = de.size;	/* set module size */
			if(mod_p->lin_addr + mod_p->size > LOMEM_MAX)
			{
				prints("memory limit exceeded with ");
				prints(str[1]);
				for(;;);
			}
			/* set up the file */
			mf.bytes_left = de.size;
			mf.curr_clus = de.start_clus_lo | (de.start_clus_hi << 16);
			mf.clus_offs = 0;
			mf.sec_offs = 4096;
			mf.fat_sec = 0;
			/* read it into memory */
			addr = mod_p->lin_addr;
			while(read_fat_byte(&mf, &b) != 255)
			{
				temp = addr;
				offs = temp & 0x0F;
				lrsh(&temp, 4);
				seg = (ushort)temp;
				pokeb(seg, offs, b);
				addr++;
			}
			num_mods++;
		}
		else if(!memcmp(str[0], "message", 7))
		{
			parse_word(f, 1, str[1], 80);	/* read the message string */
			prints(str[1]);	/* print out the message string */
			prints("\n");
		}
		else if(!memcmp(str[0], "pause", 5))
		{
			prints("Press any key to continue...\n");
			bios_getch();
		}
		else if(!memcmp(str[0], "page_align_on", 13))
		{
			page_align = 1;
		}
		else if(!memcmp(str[0], "page_align_off", 14))
		{
			page_align = 0;
		}
		else
		{
			parse_error(str[0]);
		}
	}
}

void parse_word(fat_file_t *f, char mode, uchar *str, size_t str_max)
{
	/***************************************************************************
	Parses through to next space, the next new line, or the next tab and returns
	everything it has read. If mode=1, ALL characters will be read in until a
	new line is encountered. Strips out comments only if mode=0.

	What a pain in the ass to write this thing - FM, Sept 23, 2002.
	***************************************************************************/

	size_t len=0;
	uchar c;

	str[0] = '\0';
	for(;;)
	{
		if(len == str_max)
		{
			prints("len == str_max");
			parse_error(str);
		}
		if(read_fat_byte(f, &c) == 255)
		{
			return;
		}
		if((!mode && (c == 9 || c == 13 || c == 32)) || (mode && c == 13))
		{
			if(len > 0)
			{
				return;
			}
		}
		else if(!mode && c == '#')
		{
			while(c != 13 && read_fat_byte(f, &c) != 255);
		}
		else if(c != 10 && c != 0)	/* save the character */
		{
			str[len] = c;
			len++;
			str[len] = '\0';
		}
	}
}

void parse_error(char *s)
{
	char str[20];

	prints("boot panic: fatal parse error near: ");
	prints(s);
	prints("\nstrlen is ");
	prints(ntostr(strlen(s), 10, str));
	for(;;);
}

uchar read_disk(ulong _sec, void *buf, uchar n)
{
	/***************************************************************************
	Description:
	Uses the correct CHS or LBA parameters to read the specified number of
	sectors into the buffer. This function performs all necessary translation
	of the start logical sector address.
	***************************************************************************/
	ulong num, den, rem1, rem2;
	ushort cyl;
	uchar head, sec, error;
	bios_ext_disk_xfer_t p;
	size_t i;
	char str[20];

	if(use_ext)	/* use extended int 13h */
	{
		p.packet_size = 16;
		p.reserved = 0;
		p.n = n;
		p.dest_seg = data_seg;
		p.dest_offset = (ushort)buf;
		p.lba[0] = _sec;
		p.lba[1] = 0;
		return bios_read_disk_ext(boot_drive, &p);
	}
	else	/* use old int 13h */
	{
		/* 3 tries for floppy, one otherwise */
		for(i=0; i<(boot_drive >= 0x80 ? 1 : 3); i++)
		{
			num = _sec;
			den = old_heads * old_spt;

			ldiv(&num, &den, &rem1);
			cyl = (ushort)num;
			den = old_spt;
			ldiv(&rem1, &den, &rem2);
			head = (uchar)rem1;
			sec = (uchar)rem2 + 1;

			error = bios_read_disk_old_chs(boot_drive, cyl, head, sec, n, \
				data_seg, (ushort)buf);
			if(error == 0)
			{
				return 0;
			}
			assert(!bios_reset_disk_system(boot_drive), "failed to reset drive");
		}
		return error;
	}
}

void assert(char expr, char *error_msg)
{
	if(!expr)
	{
		prints("boot panic: ");
		prints(error_msg);
		for(;;);
	}
}

char memcmp(void *_m1, void *_m2, size_t n)
{
	uchar *m1 = (uchar *)_m1, *m2 = (uchar *)_m2;
	size_t i;

	for(i=0; i<n; i++)
	{
		if(m1[i] != m2[i])
		{
			return (m1[i] > m2[i] ? 1 : -1);
		}
	}
	return 0;
}

void memcpy(void *_d, void *_s, size_t n)
{
	uchar *d = (uchar *)_d, *s = (uchar *)_s;
	size_t i;

	for(i=0; i<n; i++)
	{
		d[i] = s[i];
	}
}

ulong strton(char *str, ulong base)
{
	ulong d, v = 1, rem, n=0;
	size_t i, len = strlen(str);

	for(i=0; i<len; i++)	/* get the place value of the leftmost digit */
	{
		lmul(&v, &base);
	}
	for(i=0; i<len; i++)	/* one place at a time */
	{
		d = str[i];	/* get the digit */
		if(str[i] >= '0' && str[i] <= '9')
		{
			d -= '0';
		}
		else if(str[i] >= 'A' && str[i] <= 'Z')
		{
			d = d - 'A' + 10;
		}
		else if(str[i] >= 'a' && str[i] <= 'z')
		{
			d = d - 'a' + 10;
		}
		else
		{
			assert(0, "invalid numerical value");
		}
		lmul(&d, &v);	/* multiply it by the place to get the value */
		n+=d;	/* add it to the total */
		ldiv(&v, &base, &rem);	/* divide the place by the base */
	}

	return n;
}

size_t strlen(char *s)
{
	size_t len = 0;

	while(*s != '\0')
	{
		*s++;
		len++;
	}

	return len;
}
