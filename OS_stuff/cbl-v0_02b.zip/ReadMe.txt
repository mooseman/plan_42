---------------------------------------
| Cottontail Bootloader v0.02b README |
---------------------------------------

***********
* License *
***********

1. The Cottontail Bootloader is Copyright (C) 2000-2002, Frank Millea.

2. The Cottontail Bootloader may NOT be used for commercial purposes.

3. If you use it in your project, give me credit. If you change the source, give me credit.
Credit means a prominent name and URL reference. Don't be an asshole.

4. Use at your own risk; no warranty!

******************************
* Bugs fixed in v0.02-v0.02b *
******************************

- documentation changed to describe the 'mods' array - see the example
cbl_conf.txt included with this distro.

*****************************
* Bugs fixed in v0.01-v0.02 *
*****************************

- file size now determined by bytes, not by clusters (except in the special
case of the FAT32 root directory).

- removed 'end' command (0.01 workaround to tell parser where the config file
ended)

- the module that gets booted is now passed a pointer to the 'mods' structure
describing which modules have been loaded, and where. (pointer is in ES:BX)

- added commands 'page_align_on', and 'page_align_off', which turn page
alignment for modules on and off. They may appear anywhere in the
configuration script, and may be used as many times as desired.

***************************
* Release notes for v0.02 *
***************************

There is currently only a 1st stage bootloader for 1.44MB floppies with a FAT12 file system.
The 2nd stage bootloader works with both floppies and hard drives (up to the max size
supported by INT 13H BIOS extensions), and knows how to use FAT12, FAT16, and FAT32 file
systems. Obviously, the 1st stage bootloader somewhat limits the potential that could be
unlocked with the 2nd stage bootloader. There is only one 2nd stage bootloader, but due to
the tiny nature of the 1st stager, each media type/file system combo must have a separate
1st stager written for it. If you want one written, write it yourself; I'm simply too busy,
and I have no use for other 1st stagers at the moment.

Run BIN\MKFLOP.BAT to make a floppy with the Cottontail Bootloader on it. Prebuilt binaries
ARE included in the BIN\ dir of this distribution. If you are really ambitious, run BUILD.BAT
to rebuild the source. On-screen information is provided with both batch scripts.

****************
* How it works *
****************

The BIOS loads the first sector from the boot media to 0:7C00 in memory and jumps to it. A
sector is traditionally 512 bytes, which does not allow much space for code. These 512 bytes
compose the machine code of what is known as the "first stage" bootloader.

The 1st stage bootloader is written entirely in assembly and simply looks for the file
"CBL.BIN" in the drive's root directory. When it find it, it loads it beginning at 0:0800,
then jumps to it. The second stage bootloader then begins to execute.

Since the 2nd stage bootloader is a file on the disk, it can be slightly larger than 512
bytes, but still should be fairly small - < 16KB. The 2nd stage bootloader is mostly written
in C, but a little assembly is also used. The 2nd stage bootloader contains enough code
to mount a Microsoft FAT volume read-only, and read virtually any file(s) it desires. The
2nd stage bootloader also contains a small parser/interpreter, which is capable of executing
a configuration script. This configuration script exists in the root directory of the drive,
just like CBL.BIN (the 2nd-stage bootloader), and is named "CBL_CONF.TXT". This script
instructs CBL.BIN what files to read from the drive's root directory, and where to load them
into memory. Additional commands are also provided. See the sample CBL_CONF.TXT included in
this distribution. You can learn the ropes in about 2 minutes.

***********
* Contact *
***********

If you have problems, post them to alt.os.development. Alternatively, send me an email.

Frank Millea
frankm29a@aol.com

Mirror 1 - http://www.0xfi.com/cottontail/cbl/
Mirror 2 - http://www.cottontail-os.com/ - click on link to Cottontail Bootloader
