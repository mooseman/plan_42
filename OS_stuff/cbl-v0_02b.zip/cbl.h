#ifndef __CBL_H
#define __CBL_H

/******* typedefs *******/
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;
#ifdef size_t
#undef size_t
#endif
typedef ushort size_t;
#ifndef NULL
#define NULL 0
#endif

/*#define DEBUG*/

#include "fat.h"

/******* CBL versioning *******/
#define CBL_VER_STR "0.02"
#define CBL_VER_LEN 4

/******* low memory limit *******/
#define LOMEM_MAX 0x9F000

/******* describes a module loaded into memory *******/
#define MAX_MODS 10
typedef struct
{
	ulong lin_addr;
	ulong size;
	char name[13];
} mod_t;

/******* file system types *******/
#define FS_FAT12 0
#define FS_FAT16 1
#define FS_FAT32 2
#define FS_UNKNOWN 255

/******* function prototypes *******/
void cbl_main(void *bs, uchar drive, ushort *boot_seg, ushort *boot_offs);
void parse(fat_file_t *f);
void parse_word(fat_file_t *f, char cr, uchar *str, size_t str_max);
void parse_error(char *s);
uchar read_disk(ulong start, void *buf, uchar n);
void assert(char expr, char *error_msg);
char memcmp(void *_m1, void *_m2, size_t n);
void memcpy(void *_d, void *_s, size_t n);
ulong strton(char *str, ulong base);
size_t strlen(char *s);

/******************************************************************************/
/********************************** Text I/O **********************************/
/******************************************************************************/

void prints(char *s);
char *ntostr(ulong n, ulong b, char *s);
extern void putc(char c);
extern uchar bios_getch();

/******************************************************************************/
/************************************ Misc. ***********************************/
/******************************************************************************/

extern void lmul(ulong *m1, ulong *m2);
extern void ldiv(ulong *num, ulong *den, ulong *rem);
extern void llsh(ulong *l, uchar t);
extern void lrsh(ulong *l, uchar t);
extern void pokeb(ushort seg, ushort offs, uchar b);

/******************************************************************************/
/***************************** BIOS disk services *****************************/
/******************************************************************************/

extern uchar bios_reset_disk_system(uchar drive);
extern uchar bios_get_disk_status(uchar drive);

/******* 'old'-style CHS addressing (even w/ translation, max of 8.4GB) *******/

extern uchar bios_read_disk_old_chs(uchar drive, ushort cyl, uchar head, uchar \
	sec, uchar n, ushort dest_seg, ushort dest_offset);
extern uchar bios_get_drive_parms_old_chs(uchar drive, ushort *max_cyl, uchar *\
	max_head, uchar *max_spt);

/******* extended (LBA) addressing *******/

typedef struct
{
	uchar packet_size;	/* 16 */
	uchar reserved;		/* set to 0 */
	uchar n;		/* number of blocks to transfer */
	ushort dest_seg;
	ushort dest_offset;
	ulong lba[2];	/* 64-bit LBA sec address */
} bios_ext_disk_xfer_t;

extern uchar bios_read_disk_ext(uchar drive, bios_ext_disk_xfer_t *p);

typedef struct
{
	ushort size;	/* 26 */
	ushort flags;
	ulong num_cyls;
	ulong num_heads;
	ulong num_spt;
	ulong num_total_sectors[2];
	ushort sector_size;
} bios_ext_drive_parm_buf_t;

extern uchar bios_get_drive_parms_ext(uchar drive, bios_ext_drive_parm_buf_t *\
	b);

#endif
