/* version.c -- version number ($Revision: 1.2 $) */
#include "es.h"
static const char id[] = "@(#)es version 0.9-beta1 12-August-1997";
const char * const version = id + (sizeof "@(#)" - 1);
