
#include "syslib.h"

void main(void) {
	
	int a, b = 45;
	
	a++;
	
	a = version() + memfree() + life();
	b = module_create(b);
	
	
	if(a = module_create(b) != 0)
		a++;
	
	return;	
}


