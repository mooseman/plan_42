print "Hello from Lua"
print "Start"
for i=1,10 do
   print(i)
end
print "End"