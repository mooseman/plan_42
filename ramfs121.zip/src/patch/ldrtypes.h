/* $Id: ldrtypes.h,v 1.2 2003/11/07 07:46:20 root Exp $ */

/* OS/2 loader types */

#ifndef LDRTYPES_INCLUDED
#define LDRTYPES_INCLUDED

typedef unsigned long ulong_t;
typedef unsigned short ushort_t;
typedef unsigned char uchar_t;

#endif
