int InfoQuery (PCHAR pData, USHORT cbData, int level, PDIRENTRY pEntry);
int InfoSet (PCHAR pData, USHORT cbData, int level, PDIRENTRY pEntry, struct sffsi *psffsi);
