int EaGetList (PFEALIST pFEAList, PEAOP pEAOP, PBLOCK pblkEA);
int EaAddList (PBLOCK pblkEA, PEAOP pEAOP);
